@echo off
:back
cls
set /p chance="Please enter the chance for random key press: "
if %chance% GTR 1 (
    echo %chance% > output.txt
    exit /b
)
else (
    echo.
    echo "You must enter a integer greater than 1."
    timeout /t 2 >nul
    goto back
)