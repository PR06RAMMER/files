@echo off
del /f /q output.txt 2>nul